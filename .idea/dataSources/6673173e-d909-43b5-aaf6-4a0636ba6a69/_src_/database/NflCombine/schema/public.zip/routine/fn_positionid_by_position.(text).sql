create function fn_positionid_by_position(position_name text) returns bigint
LANGUAGE SQL
AS $$
select id from position where name = position_name;
$$;
